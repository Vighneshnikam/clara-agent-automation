
# Clara Agent Automation Pipeline

Zero‑cost automation pipeline that converts demo and onboarding call transcripts into structured configuration for Retell voice agents.

## Architecture

Pipeline A (Demo Call → v1 Agent)

Demo Transcript
→ Data Extraction
→ Account Memo JSON
→ Agent Spec v1
→ Stored in outputs/accounts

Pipeline B (Onboarding Call → v2 Agent)

Onboarding Transcript
→ Patch Engine
→ Updated Memo
→ Agent Spec v2
→ Changelog

## Tech Stack

Automation: n8n (local)
Storage: JSON files
Language: Python

## Running

1. Place demo transcripts in:
inputs/demo_calls

2. Place onboarding transcripts in:
inputs/onboarding_calls

3. Run scripts

python scripts/extract_data.py

Outputs will appear in:
outputs/accounts

## Repo Structure

/workflows
/scripts
/inputs
/outputs
/changelog
