
import json, os

def extract_account_data(transcript):
    data = {
        "company_name": "Unknown Company",
        "services_supported": [],
        "emergency_definition": [],
        "notes": transcript[:200]
    }

    t = transcript.lower()

    if "sprinkler" in t:
        data["services_supported"].append("sprinkler repair")

    if "alarm" in t:
        data["services_supported"].append("fire alarm service")

    if "leak" in t:
        data["emergency_definition"].append("sprinkler leak")

    return data


def main():
    input_folder = "../inputs/demo_calls"
    output_folder = "../outputs/accounts"
    os.makedirs(output_folder, exist_ok=True)

    for file in os.listdir(input_folder):
        with open(os.path.join(input_folder, file)) as f:
            transcript = f.read()

        account_id = file.split(".")[0]

        data = extract_account_data(transcript)

        account_dir = os.path.join(output_folder, account_id, "v1")
        os.makedirs(account_dir, exist_ok=True)

        with open(os.path.join(account_dir, "account_memo.json"), "w") as out:
            json.dump(data, out, indent=2)


if __name__ == "__main__":
    main()
