
import json

def generate_agent_spec(account):

    return {
        "agent_name": f"Clara - {account.get('company_name','Company')}",
        "voice_style": "professional",
        "version": "v1",
        "system_prompt": "You are Clara, the AI receptionist.",
        "call_transfer_protocol": {
            "timeout_seconds": 60,
            "retries": 2
        }
    }
