
def apply_patch(v1, update):
    v2 = v1.copy()
    for k,v in update.items():
        v2[k] = v
    return v2
